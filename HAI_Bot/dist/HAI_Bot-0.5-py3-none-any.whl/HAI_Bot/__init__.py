from .ChatBot import HAI as HAI_model

__all__ = [
    'HAI',
]